<h1 class="entry-title">
	<?php _e( 'Staff Profile', 'themeboy' ); ?>
</h1>
<div id="content" role="main">
	<?php echo do_shortcode( '[tb_staff id=' . $post->ID .']' ); ?>
</div><!-- #content-## -->