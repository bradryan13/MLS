<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<ul>
		<li class="query"><input type="text" value="" name="s" id="s" /></li>
		<li><input type="submit" id="searchsubmit" value="<?php _e( 'Search' ); ?>" /></li>
	</ul>
</form>